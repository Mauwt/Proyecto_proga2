
#include "headers/CMenu.h"

int main() {

    CMenu menu;
    menu.ejecutar();
    return 0;
}